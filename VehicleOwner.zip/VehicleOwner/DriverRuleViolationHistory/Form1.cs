﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriverRuleViolationHistory
{
    public partial class Form1 : Form
    {
        Microsoft.Office.Interop.Excel.Workbook ExWorkbook;
        Microsoft.Office.Interop.Excel.Worksheet ExWorksheet;
        Microsoft.Office.Interop.Excel.Range ExRange;
        Microsoft.Office.Interop.Excel.Application ExObj;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.ForeColor = Color.White;
            label2.ForeColor = Color.White;
            label3.ForeColor = Color.White;

            label3.Font = new Font(FontFamily.GenericSansSerif, 18.0F, FontStyle.Bold);
            
            this.BackColor = Color.LightSeaGreen;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadExcel();
        }

        private void LoadExcel()
        {
            try
            {
                DataTable dt = new DataTable("dataTable");
                DataSet dsSource = new DataSet("dataSet");
                dt.Reset();

                ExObj = new Microsoft.Office.Interop.Excel.Application();

                ExWorkbook = ExObj.Workbooks.Open(@"D:\Traffic_Violations1.xlsx", Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                ExWorksheet = (Microsoft.Office.Interop.Excel.Worksheet)ExWorkbook.Sheets.get_Item(1);
                ExRange = ExWorksheet.UsedRange;

                for (int Cnum = 1; Cnum <= ExRange.Columns.Count; Cnum++)
                {
                    dt.Columns.Add(new DataColumn((ExRange.Cells[1, Cnum] as Microsoft.Office.Interop.Excel.Range).Value2.ToString()));
                }
                dt.AcceptChanges();

                string[] columnNames = new String[dt.Columns.Count];
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    columnNames[0] = dt.Columns[i].ColumnName;
                }
                //string[] columnNames = (from dc in dt.Columns.Cast<DataColumn>() select dc.ColumnName).ToArray();

                for (int Rnum = 2; Rnum <= ExRange.Rows.Count; Rnum++)
                {
                    if (((ExRange.Cells[Rnum, 1] as Microsoft.Office.Interop.Excel.Range).Value2 != null &&
                        (ExRange.Cells[Rnum, 1] as Microsoft.Office.Interop.Excel.Range).Value2 != textBox1.Text.Trim()) 
                        &&
                        ((ExRange.Cells[Rnum, 2] as Microsoft.Office.Interop.Excel.Range).Value2 != null &&
                        Convert.ToString((ExRange.Cells[Rnum, 2] as Microsoft.Office.Interop.Excel.Range).Value2) != textBox2.Text.ToString().Trim()))
                    {
                        continue;
                    }
                    else
                    {
                        DataRow dr = dt.NewRow();
                        for (int Cnum = 1; Cnum <= ExRange.Columns.Count; Cnum++)
                        {
                            if ((ExRange.Cells[Rnum, Cnum] as Microsoft.Office.Interop.Excel.Range).Value2 != null)
                            {
                                dr[Cnum - 1] = (ExRange.Cells[Rnum, Cnum] as Microsoft.Office.Interop.Excel.Range).Value2.ToString();
                            }
                        }
                        dt.Rows.Add(dr);
                        dt.AcceptChanges();
                    }
                }
                ExWorkbook.Close(true, Missing.Value, Missing.Value);
                ExObj.Quit();

                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
