from PIL import Image, ImageDraw
import cv2
import numpy
POLYGON_MASK = [
    (0, 0),
    (0, 288),
    (44, 288),
    (140, 125),
    (160, 125),
    (164, 288),
    (352, 288),
    (352, 0),
]
CROP_RECT = (44, 125, 164, 286)
def count_unmasked_pixels(pil_image):
    pixels = pil_image.load()
    count = 0
    for x in range(0, pil_image.size[0]):
        for y in range(0, pil_image.size[1]):
            if pixels[x, y] != (0, 0, 0):
                count = count + 1
    return count

def count_edge_pixels(opencv_image):
    count = 0
    width, height = opencv_image.shape[:2]
    for x in range(0, width):
        for y in range(0, height):
            if opencv_image[x, y] == 255:
                count = count + 1
    return count

def calculate_traffic_score(file_path):
    image = Image.open(file_path)
    ImageDraw.Draw(image).polygon(POLYGON_MASK, fill=(0, 0, 0), outline=True)
    cropped_image = image.crop(CROP_RECT)
    unmasked_pixels = count_unmasked_pixels(cropped_image)
    opencv_image = cv2.cvtColor(numpy.array(cropped_image), cv2.COLOR_RGB2BGR)
    edged_image = cv2.Canny(opencv_image, 100, 200)
    edge_pixels = count_edge_pixels(edged_image)
    print(float(edge_pixels) / float(unmasked_pixels))
    return float(edge_pixels) / float(unmasked_pixels)

calculate_traffic_score('D:\\Abhijit\\Learning\\Hinjawadi Hackathon\\Final Presentation\\RealTimeRoadStatus.jpg')
